﻿using ClassDiagram.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClassDiagram
{
   
    public partial class PatientGUI : Window
    {
        public PatientGUI(Patient patient)
        {
            InitializeComponent();
            DataContext = patient;
            lvDataBinding.ItemsSource = patient.appointment;

        }

        private void makeAppointment(object sender, RoutedEventArgs e)
        {
            Patient patient = (Patient)DataContext;
            var appt = new AppointmentGUI(patient);
            appt.Show();
            Close();
        }

        private void cancelAppointment(object sender, RoutedEventArgs e)
        {
            Patient patient = (Patient)DataContext;
            Appointment appointment = (Appointment)lvDataBinding.SelectedItem;
            FileStorage fs = new FileStorage();
            ObservableCollection<Patient> pacijenti = fs.GetAllPatients();
            if (appointment == null)
            {
                MessageBox.Show("Niste izabrali nijedan pregled!");
            }
            else
            {

                foreach (Patient p in pacijenti)
                {
                    if (p.contact == patient.contact)
                    {
                        foreach (Appointment a in p.appointment.ToArray())
                        {
                            if (a.dateAndTime == appointment.dateAndTime)
                            {
                                p.RemoveAppointment(a);
                                fs.SavePatient("patients.xml", pacijenti);
                                patient.RemoveAppointment(appointment);
                                MessageBox.Show("Pregled je uspešno otkazan!");
                                lvDataBinding.Items.Refresh();
                            }
                        }
                    }
                }

            }
        }
        private void rescheduleAppointment(object sender, RoutedEventArgs e)
        {
            Appointment appointment = (Appointment)lvDataBinding.SelectedItem;
            Patient patient = (Patient)DataContext;
            if (appointment == null)
            {
                MessageBox.Show("Niste izabrali nijedan pregled!");
            }
            else
            {
                RescheduleAppointmentGUI gui = new RescheduleAppointmentGUI(appointment, patient);
                gui.Show();
                Close();
            }
        }
    }
}
