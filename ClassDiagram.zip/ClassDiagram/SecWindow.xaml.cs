﻿using ClassDiagram.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace ClassDiagram
{
    /// <summary>
    /// Interaction logic for SecWindow.xaml
    /// </summary>
    public partial class SecWindow : Window
    {
        public SecWindow()
        {
            InitializeComponent();

            Model.Patient pacijent1 = new Model.Patient("Marko", "Markovic", 12345, "15.Avgust48a", 0600470, Gender.Male,"Krivaja",true);
            DtgPacijenti.Items.Add(pacijent1);
        }


        private void FuncDelete(object sender, RoutedEventArgs e)
        {

        }

        private void FuncEdit(object sender, RoutedEventArgs e)
        {
           
        }

        private void FuncAdd(object sender, RoutedEventArgs e)
        {
            var prozor = new AddPatientWindow();
            prozor.Show();
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
