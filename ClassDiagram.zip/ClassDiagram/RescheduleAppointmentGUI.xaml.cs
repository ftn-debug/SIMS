﻿using ClassDiagram.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ClassDiagram
{

    public partial class RescheduleAppointmentGUI : Window
    {
        Appointment newAppointment = new Appointment();
        bool datum = true;
        bool lekar = false;
        private Patient patient1;

        public RescheduleAppointmentGUI(Appointment appointment, Patient patient)
        {
            InitializeComponent();
            FileStorage storage = new FileStorage();
            ObservableCollection<Doctor> doctors = storage.GetAllDoctors();
            comboBox.ItemsSource = doctors;
            DataContext = appointment;
            patient1 = patient;
        }

        private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

            var picker = sender as DatePicker;
            DateTime? date = picker.SelectedDate;
            if (date == null || date <= DateTime.Now)
            {
                datum = false;
            }
            else
            {
                datum = true;
                newAppointment.dateAndTime = (DateTime)date;
            }
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var combo = sender as ComboBox;
            Doctor doctor = (Doctor)combo.SelectedItem;
            if (doctor == null)
            {
                lekar = false;
            }
            else
            {
                lekar = true;
                newAppointment.doctor = doctor;
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!lekar)
            {
                MessageBox.Show("Niste izabrali zeljenog lekara!");
            }
            else if (!datum)
            {
                MessageBox.Show("Izabran je pogresan datum!");
            }
            else
            {
                Appointment appointment = (Appointment)DataContext;
                FileStorage fs = new FileStorage();
                ObservableCollection<Patient> pacijenti = fs.GetAllPatients();
                foreach (Patient p in pacijenti)
                {
                    if (p.contact == patient1.contact)
                    {
                        foreach (Appointment a in p.appointment.ToArray())
                        {
                            if (a.appointmentID == appointment.appointmentID)
                            {
                                a.dateAndTime = newAppointment.dateAndTime;
                                a.doctor = newAppointment.doctor;
                                a.Doctor = newAppointment.Doctor;
                                fs.SavePatient("patients.xml", pacijenti);
                            }
                        }
                    }
                }
                MessageBox.Show("Pregled je uspešno promenjen!");
                PatientGUI gui = new PatientGUI(patient1);
                gui.Show();
                Close();

            }

        }


    }
}
