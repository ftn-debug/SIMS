/***********************************************************************
 * Module:  TipProstorija.cs
 * Author:  majab
 * Purpose: Definition of the Enum CRUDUpravnik.TipProstorija
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
   public class TipProstorija
   {
      private Soba soba;
      private TipProstorija sala;
      private Ordinacija ordinacija;
   
   }
}