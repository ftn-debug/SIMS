/***********************************************************************
 * Module:  RenovacijaProstorije.cs
 * Author:  majab
 * Purpose: Definition of the Class CRUDUpravnik.RenovacijaProstorije
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
   public class RoomRenovation
   {

        public DateTime startTime;
        public DateTime endTime;
        public Boolean isFinished;

        public Room room;

        public RoomRenovation (Room room, DateTime startTime, DateTime endTime)
      {
            this.room = room;
            this.startTime = startTime;
            this.endTime = endTime;
      }
     
   
   }
}