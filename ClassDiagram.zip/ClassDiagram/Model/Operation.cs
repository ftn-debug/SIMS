/***********************************************************************
 * Module:  Operacija.cs
 * Author:  Kleopatra
 * Purpose: Definition of the Class Model.Operacija
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
    [Serializable]
    public class Operation
   {
      public DateTime dateAndTime;
      public String operationID;
      
      public Sala sala;
      
      public Sala Sala
      {
         get
         {
            return sala;
         }
         set
         {
            this.sala = value;
         }
      }
      public Doctor doctor;
      
      public Doctor Doctor
      {
         get
         {
            return doctor;
         }
         set
         {
            if (this.doctor == null || !this.doctor.Equals(value))
            {
               if (this.doctor != null)
               {
                  Doctor oldDoctor = this.doctor;
                  this.doctor = null;
                  oldDoctor.RemoveOperations(this);
               }
               if (value != null)
               {
                  this.doctor = value;
                  this.doctor.AddOperations(this);
               }
            }
         }
      }
      public Patient patient;
      
      public Patient Patient
      {
         get
         {
            return patient;
         }
         set
         {
            this.patient = value;
         }
      }
   
   }
}