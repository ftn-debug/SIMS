/***********************************************************************
 * Module:  Soba.cs
 * Author:  majab
 * Purpose: Definition of the Class CRUDUpravnik.Soba
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
   public class Soba : Room
   {
      public new Boolean Edit()
      {
         throw new NotImplementedException();
      }
      
      public new Boolean Update()
      {
         throw new NotImplementedException();
      }
      
      public new Boolean Delete()
      {
         throw new NotImplementedException();
      }
      
      public new Boolean SetAvailability()
      {
         throw new NotImplementedException();
      }
   
   }
}