/***********************************************************************
 * Module:  ZdravstveniKarton.cs
 * Author:  Lenovo
 * Purpose: Definition of the Class Model.ZdravstveniKarton
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
   public class MedicalRecord
   {
   }
}