/***********************************************************************
 * Module:  FileStorage.cs
 * Author:  Bogdanovic
 * Purpose: Definition of the Class Model.FileStorage
 ***********************************************************************/

using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Xml.Serialization;

namespace ClassDiagram.Model
{
   public class FileStorage
   {
        private string fileName;

        private ObservableCollection<Patient> patients { get; set; }
        private ObservableCollection<Doctor> doctors { get; set; }

        public FileStorage()
        {
            /*patients = new ObservableCollection<Patient>();
            var patient1 = new Patient();
            patient1.name = "Ognjen";
            patient1.lastName = "Bogdanovic";
            patient1.adress = "Trg Kralja Petra I, Zabalj";
            patient1.contact = 0638314856;
            patient1.insurance = true;
            patient1.dateOfBirth = DateTime.Parse("12-06-1999");

            var patient2 = new Patient();
            patient2.name = "Grozdana";
            patient2.lastName = "Tepic";
            patient2.adress = "Temerinska 32, Novi Sad";
            patient2.contact = 0635878467;
            patient2.insurance = true;
            patient2.dateOfBirth = DateTime.Parse("09/28/1999");
            patients.Add(patient1);
            patients.Add(patient2);
            fileName = "patients.xml";
            SavePatient(fileName, patients);*/


            doctors = new ObservableCollection<Doctor>();
            var doctor1 = new Doctor();
            doctor1.name = "Predrag";
            doctor1.lastName = "Kon";
            doctor1.doctorID = "0923";
            var doctor2 = new Doctor();
            doctor2.name = "Branimir";
            doctor2.lastName = "Nestorovic";
            doctor2.doctorID = "1512";
            doctors.Add(doctor1);
            doctors.Add(doctor2);
        }

        public void SaveAll()
        {
            throw new NotImplementedException();
        }

        public ObservableCollection<Patient> GetAllPatients()
        {
            
            return LoadFromFile("patients.xml");
        }

        public ObservableCollection<Doctor> GetAllDoctors()
        {

            return doctors;
        }

        public void SavePatient(string filePath, ObservableCollection<Patient> pacijent)
        {
            using (FileStream stream = new FileStream(filePath, FileMode.Create))
            {
                var xml = new XmlSerializer(typeof(ObservableCollection<Patient>));
                xml.Serialize(stream, pacijent);
            }
        }

        public ObservableCollection<Patient> LoadFromFile(string filePath)
        {
            using (FileStream stream = new FileStream(filePath, FileMode.Open))
            {
                var xml = new XmlSerializer(typeof(ObservableCollection<Patient>));
                return (ObservableCollection<Patient>)xml.Deserialize(stream);
            }
        }

    }

}
