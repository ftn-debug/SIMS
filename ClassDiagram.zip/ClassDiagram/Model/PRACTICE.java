public class Server{
	
	
	public static final int TCP_PORT = 9000;
	public static void main(){
		
		try{
		
		ServerSocket ss = new ServerSocket(TCP_PORT);
		
		while(true){
		Socket sock = ss.accept();
		//... sad nesto radimo
		new ServerThread(sock);
			
		}
		
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
	}
}


public class ServerThread extends Thread {
	
	
	public ServerThread(Socket sock){
		this.sock = sock;
		
		in = 
		out = 
		
		
		
	}
	
	
	
	
}































