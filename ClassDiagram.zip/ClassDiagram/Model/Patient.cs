using System;
using System.Xml.Serialization;

namespace ClassDiagram.Model
{
    [XmlInclude(typeof(Appointment))]
    [Serializable]
    public class Patient : Guest
   {
     
      public string placeOfBirth;
      public bool insurance;
      
      public MedicalRecord medicalRecord;
      public System.Collections.ArrayList appointment { get; set; }

      public Patient()
        {

        }
      public Patient(string ime, string prezime, int jmbg, string adresa, int kontakt, Gender pol, string mestoRodj, bool osiguranje)
      {
          name = ime;
          lastName = prezime;
          id = jmbg;
          adress = adresa;
          contact = kontakt;
          gender = pol;
          placeOfBirth = mestoRodj;
          insurance = osiguranje;

      }

      /*  public System.Collections.ArrayList Appointment
      {
         get
         {
            if (appointment == null)
               appointment = new System.Collections.ArrayList();
            return appointment;
         }
         set
         {
            RemoveAllAppointment();
            if (value != null)
            {
               foreach (Appointment oAppointment in value)
                  AddAppointment(oAppointment);
            }
         }
      }*/
      
      
      public void AddAppointment(Appointment newAppointment)
      {
         if (newAppointment == null)
            return;
         if (this.appointment == null)
            this.appointment = new System.Collections.ArrayList();
         if (!this.appointment.Contains(newAppointment))
            this.appointment.Add(newAppointment);
      }
      
      public void RemoveAppointment(Appointment oldAppointment)
      {
         if (oldAppointment == null)
            return;
         if (this.appointment != null)
            if (this.appointment.Contains(oldAppointment))
               this.appointment.Remove(oldAppointment);
      }
      
      public void RemoveAllAppointment()
      {
         if (appointment != null)
            appointment.Clear();
      }

      private bool LogIn()
      {
         throw new NotImplementedException();
      }

      public bool EditAppointment(Appointment appointment)
      {
         throw new NotImplementedException();
      }


    }
}