/***********************************************************************
 * Module:  Inventory.cs
 * Author:  majab
 * Purpose: Definition of the Class CRUDUpravnik.Inventory
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
   public abstract class Inventory
   {
      public int id;
      public String name;
   
   }
}