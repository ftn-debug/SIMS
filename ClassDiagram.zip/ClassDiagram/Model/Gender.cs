/***********************************************************************
 * Module:  Pol.cs
 * Author:  Lenovo
 * Purpose: Definition of the Enum Model.Pol
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
   public enum Gender
    {
      Male,
      Female
   
   }
}