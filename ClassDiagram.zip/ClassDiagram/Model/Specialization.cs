/***********************************************************************
 * Module:  Specijalizacija.cs
 * Author:  Kleopatra
 * Purpose: Definition of the Enum Model.Specijalizacija
 ***********************************************************************/

using System;

namespace ClassDiagram.Model
{
   public class Specialization
   {
      private int lekarOpstePrakse;
      private int kardiolog;
      private int pulmolog;
      private int internista;
      private int otorinolaringolog;
      private int oftamolog;
      private int dermatolog;
   
   }
}