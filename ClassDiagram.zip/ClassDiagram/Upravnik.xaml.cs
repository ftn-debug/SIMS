﻿using ClassDiagram.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace ClassDiagram
{
    /// <summary>
    /// Interaction logic for Upravnik.xaml
    /// </summary>
    public partial class Upravnik : Window, INotifyPropertyChanged

    {
        public ObservableCollection<Room> allRooms { get; set; }
        public RoomIventory inventory = null;

        public Upravnik()
        {
            InitializeComponent();
            this.DataContext = this;



           inventory = new RoomIventory();
           inventory.init();
            //  Nisam uspjela da povezem ovo polje i klasu

          
            allRooms = new ObservableCollection<Room>(inventory.room);

            Console.WriteLine("Da li radi ovaj ispis ?");

            System.Diagnostics.Debug.WriteLine("Ovaj ispis radi ");


        }

        public event PropertyChangedEventHandler PropertyChanged;
        public Boolean button_is_clicked = false;
        private void Button_Click_renovate(object sender, RoutedEventArgs e)
        {
            Room selected = (Room)MyList.SelectedItem;

            var s = new Rennovation();
            s.Show();
           
           
          

                DateTime start = s.Pocetak.SelectedDate.HasValue ? s.Pocetak.SelectedDate.Value : new DateTime();
                DateTime end = s.Kraj.SelectedDate.HasValue ? s.Pocetak.SelectedDate.Value : new DateTime();

                inventory.GetRoom(selected).ActivateRennovation(start, end);
                selected.availability = false;
                MyList.Items.Refresh();

           
        }

        private void Potvrdi_Click(object sender, RoutedEventArgs e)
        {
           
    }

        private void Button_Click_add(object sender, RoutedEventArgs e)
        {


            string s1 = MyValue.Text;
            string s2 = MyLocation.Text;

            // ComboBoxItem item = BoxTip.Selctedtem
            // TipProstorija.Tip tp = (TipProstorija.Tip)BoxTip.SelectedItem;
            int indeks = BoxTip.SelectedIndex;


            if (indeks == 0)
            {
                Sala s = new Sala(s1, TipProstorija.Tip.Sala, s2);

                if(inventory.AddRoom(s))
                allRooms.Add(s);

               // allRooms.Add(s);
                
            }
            else if (indeks == 1)
            {
                Soba s = new Soba(s1, TipProstorija.Tip.Soba, s2);

                if (inventory.AddRoom(s))
               
                    allRooms.Add(s);
            }
            else
            {
                Ordinacija s = new Ordinacija(s1, TipProstorija.Tip.Ordinacija, s2);

               if (inventory.AddRoom(s))
                    allRooms.Add(s);
            }
        }
        private void Button_Click_edit(object sender, RoutedEventArgs e)
        {
            string s1 = MyValue.Text;
            string s2 = MyLocation.Text;
            //---Combo box problem -----------

            // ComboBoxItem item = BoxTip.Selctedtem
            // TipProstorija.Tip tp = (TipProstorija.Tip)BoxTip.SelectedItem;
            int indeks = BoxTip.SelectedIndex;

            TipProstorija.Tip tp;
            if (indeks == 0)
            {
                tp = TipProstorija.Tip.Sala;

            }
            else if (indeks == 1)
            {
                tp = TipProstorija.Tip.Soba;
            }
            else
            {
                tp = TipProstorija.Tip.Ordinacija;
            }
            Room selected = (Room)MyList.SelectedItem;
            inventory.EditRoom(selected, s1, tp, s2);
            selected.name = s1;
            selected.location = s2;
            selected.roomType = tp;
            MyList.Items.Refresh();


            
        }
        private void Button_Click_delete(object sender, RoutedEventArgs e)
        {
            Room selected = (Room)MyList.SelectedItem;

            inventory.RemoveRoom(selected);
            allRooms.Remove(selected);

        }
        private void MyList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }

    }
